import { useState, useEffect } from 'react';
import type { Template } from '../types'; // Importe seus tipos se estiverem em outro lugar

export function useAutoTemplates(): Template[] {
  const [folderTemplates, setFolderTemplates] = useState<Template[]>([]);

  useEffect(() => {
    // 1. Carrega todas as imagens dentro de src/assets/templates
    const modules = import.meta.glob('/src/assets/templates/**/*.{png,jpg,jpeg,webp}', {
      eager: true,
      as: 'url'
    });

    const newTemplates: Template[] = [];

    // 2. Transforma cada arquivo num objeto Template compatível com seu App
    let counter = 0;
    for (const path in modules) {
      const imageUrl = modules[path];
      
      // Extrai a categoria pelo nome da pasta (ex: .../templates/Dark/img.png -> "Dark")
      const parts = path.split('/');
      const categoryRaw = parts[parts.length - 2];
      // Capitaliza a primeira letra (dark -> Dark)
      const category = categoryRaw.charAt(0).toUpperCase() + categoryRaw.slice(1);
      
      const fileName = parts[parts.length - 1].split('.')[0];

      newTemplates.push({
        id: `auto-${category}-${counter++}`, // ID único
        name: fileName,
        category: category,
        backgroundType: 'image',
        value: imageUrl,
        textColor: '#ffffff', // Padrão
        fontFamily: 'Inter',  // Padrão
        overlayOpacity: 0.2
      });
    }

    setFolderTemplates(newTemplates);
  }, []);

  return folderTemplates;
}