
// Aponta para o ficheiro temporário limpo
import { content } from './contentcopia.ts'; 

import fs from 'fs';

// ... o resto igual
const jsonString = JSON.stringify(content, null, 2);
fs.writeFileSync('minhas_frases.json', jsonString);
console.log('✅ Sucesso!');