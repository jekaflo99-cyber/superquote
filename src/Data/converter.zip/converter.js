// Ajusta o './content.ts' para o caminho do teu ficheiro
// Se o teu ficheiro usa "export default", usa .default
// Se usa "export const content", usa .content
const dados = require('./content.ts'); 

const fs = require('fs');

// Se o import vier como objeto 'module', tenta aceder à propriedade correta
const objetoFinal = dados.default || dados.content || dados;

fs.writeFileSync('minhas_frases.json', JSON.stringify(objetoFinal, null, 2));
console.log("Ficheiro JSON criado com sucesso!");