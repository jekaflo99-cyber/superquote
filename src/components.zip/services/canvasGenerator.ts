
import { type EditorConfig, type Template } from '../types';

/**
 * Generates a Blob from the configuration using HTML5 Canvas.
 * This simulates the Android Canvas drawing process but for Web.
 */
export const generateImage = async (
  config: EditorConfig,
  template: Template,
  width: number,
  height: number,
  isPremium: boolean,
  excludeText: boolean = false
): Promise<Blob | null> => {
  // Base reference width is 1080px.
  // We calculate a scale multiplier for higher resolutions (e.g. 2048px).
  const baseWidth = 1080;
  const scaleMultiplier = width / baseWidth;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  if (!ctx) return null;

  // 1. Draw Background
  if (template.backgroundType === 'solid') {
    ctx.fillStyle = template.value;
    ctx.fillRect(0, 0, width, height);
  } else if (template.backgroundType === 'gradient') {
    // Basic gradient parsing simulation for linear gradients
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    if (template.value.includes('#f6d365')) {
       gradient.addColorStop(0, '#f6d365');
       gradient.addColorStop(1, '#fda085');
    } else if (template.value.includes('#30cfd0')) {
       gradient.addColorStop(0, '#30cfd0');
       gradient.addColorStop(1, '#330867');
    } else {
       // Fallback for unparsed gradients
       ctx.fillStyle = '#333';
       ctx.fillRect(0,0, width, height);
    }
    
    // Check if context style was set to gradient (it wasn't in previous fallback block)
    if (template.value.includes('linear-gradient')) {
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
    }
  } else if (template.backgroundType === 'image') {
    try {
      const img = new Image();
      img.crossOrigin = "anonymous";
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        img.src = template.value;
      });
      
      // Cover logic
      const scale = Math.max(width / img.width, height / img.height);
      const x = (width / 2) - (img.width / 2) * scale;
      const y = (height / 2) - (img.height / 2) * scale;
      ctx.drawImage(img, x, y, img.width * scale, img.height * scale);

      // Overlay
      if (template.overlayOpacity) {
        ctx.fillStyle = `rgba(0,0,0,${template.overlayOpacity})`;
        ctx.fillRect(0, 0, width, height);
      }
    } catch (e) {
      console.error("Failed to load image", e);
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, width, height);
    }
  }

  // If excludeText is true, we stop here (used for preview background only)
  if (excludeText) {
      return new Promise((resolve) => {
        canvas.toBlob((blob) => {
          resolve(blob);
        }, 'image/jpeg', 0.9);
      });
  }

  // 2. Configure Text Font & Style
  const baseScaleFactor = 3.6; 
  const scaleFactor = baseScaleFactor * scaleMultiplier;
  const fontSize = config.fontSize * scaleFactor;
  
  const fontWeight = config.isBold ? 'bold' : 'normal';
  const fontStyle = config.isItalic ? 'italic' : 'normal';
  ctx.font = `${fontStyle} ${fontWeight} ${fontSize}px ${config.fontFamily}`;
  ctx.textBaseline = 'middle';
  
  // Letter Spacing (New Feature)
  if (config.letterSpacing) {
      // Use canvas letterSpacing if supported, else ignore (polyfill is complex)
      (ctx as any).letterSpacing = `${config.letterSpacing * scaleFactor}px`;
  } else {
      (ctx as any).letterSpacing = '0px';
  }

  // Text Transform (New Feature)
  let textToDraw = config.text;
  if (config.textTransform === 'uppercase') textToDraw = textToDraw.toUpperCase();
  if (config.textTransform === 'lowercase') textToDraw = textToDraw.toLowerCase();

  // 3. Text Wrapping
  const maxWidth = width * 0.85; // 85% width padding
  const words = textToDraw.split(' ');
  const lines = [];
  let currentLine = words[0];

  for (let i = 1; i < words.length; i++) {
    const word = words[i];
    const width = ctx.measureText(currentLine + " " + word).width;
    if (width < maxWidth) {
      currentLine += " " + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  lines.push(currentLine);

  // 4. Calculate Positioning
  const lineHeightMultiplier = config.lineHeight || 1.4;
  const pxLineHeight = fontSize * lineHeightMultiplier;
  const totalTextHeight = lines.length * pxLineHeight;
  
  let startY = height / 2; // default center
  if (config.verticalAlign === 'top') startY = height * 0.2;
  if (config.verticalAlign === 'bottom') startY = height * 0.8 - totalTextHeight;
  
  // Adjust for vertical centering of the block
  if (config.verticalAlign === 'center') {
      startY = (height - totalTextHeight) / 2 + (pxLineHeight / 2);
  }

  // 5. Draw Text Background (Offline Buffer to prevent Overlap)
  if (config.textBackgroundOpacity > 0) {
      const bgCanvas = document.createElement('canvas');
      bgCanvas.width = width;
      bgCanvas.height = height;
      const bgCtx = bgCanvas.getContext('2d');

      if (bgCtx) {
          // Box Gradient Logic
          if (config.boxGradientColors && config.boxGradientColors.length >= 2) {
              const bgGradient = bgCtx.createLinearGradient(0, 0, width, height); // Diagonal gradient for box
              config.boxGradientColors.forEach((color, index) => {
                  bgGradient.addColorStop(index / (config.boxGradientColors!.length - 1), color);
              });
              bgCtx.fillStyle = bgGradient;
          } else {
              bgCtx.fillStyle = config.textBackgroundColor;
          }

          const radius = 0; // 0x Radius (Sharp corners)
          
          let paddingY = 0;
          let paddingX = 0;

          if (config.textBoxStyle === 'highlight') { // "Fit" mode
             // Minimal Padding 2px (at scale)
             paddingY = fontSize * 0.04; // ~2px scaled
             paddingX = fontSize * 0.01; // ~0.5px scaled
          } else { // "Block" mode
             paddingY = fontSize * 0.2; // Standard padding
             paddingX = fontSize * 0.35;
          }

          // Draw Single Block (Unified Box Style)
          let maxLineWidth = 0;
          lines.forEach(line => {
              const w = ctx.measureText(line).width;
              if (w > maxLineWidth) maxLineWidth = w;
          });
          
          if (config.textAlign === 'justify' && lines.length > 1) {
              maxLineWidth = maxWidth;
          }

          const boxWidth = maxLineWidth + (paddingX * 2);
          const boxHeight = totalTextHeight + (paddingY * 2) - (pxLineHeight - fontSize); 

          let boxX = 0;
          if (config.textAlign === 'center') {
              boxX = (width - boxWidth) / 2;
          } else if (config.textAlign === 'left') {
              boxX = (width * 0.075) - paddingX;
          } else if (config.textAlign === 'right') {
              boxX = (width * 0.925) + paddingX - boxWidth;
          } else if (config.textAlign === 'justify') {
              boxX = (width * 0.075) - paddingX;
          }

          // Adjust Y to center the box around the text block
          const boxY = startY - (pxLineHeight / 2) - paddingY + (pxLineHeight - fontSize) / 2; 

          bgCtx.beginPath();
          bgCtx.roundRect(boxX, boxY, boxWidth, boxHeight, radius);
          bgCtx.fill();

          // Composite the background layer onto main canvas
          ctx.save();
          ctx.globalAlpha = config.textBackgroundOpacity;
          ctx.drawImage(bgCanvas, 0, 0);
          ctx.restore();
      }
  }

  // Helper to draw lines with specific settings
  const drawLines = (drawFn: (line: string, x: number, y: number, isJustify: boolean, justifyWidth: number) => void) => {
      lines.forEach((line, index) => {
        const y = startY + (index * pxLineHeight);
        
        // Justify Logic
        if (config.textAlign === 'justify') {
            const lineWords = line.split(' ');
            if (lineWords.length > 1 && index < lines.length - 1) { // Don't justify last line
                const totalWidthOfWords = lineWords.reduce((acc, word) => acc + ctx.measureText(word).width, 0);
                const spaceAvailable = maxWidth - totalWidthOfWords;
                const spacePerWord = spaceAvailable / (lineWords.length - 1);
                
                let currentX = width * 0.075;
                
                lineWords.forEach((word) => {
                    drawFn(word, currentX, y, false, 0);
                    currentX += ctx.measureText(word).width + spacePerWord;
                });
            } else {
                // Last line or single word behaves like left align
                const xPos = width * 0.075;
                drawFn(line, xPos, y, false, 0);
            }
        } else {
            // Standard Align
            ctx.textAlign = config.textAlign as CanvasTextAlign;
            let xPos = width / 2;
            if (config.textAlign === 'left') xPos = width * 0.075;
            if (config.textAlign === 'right') xPos = width * 0.925;
            
            drawFn(line, xPos, y, false, 0);
        }
      });
  };

  // 6. Draw Glow Pass (Behind everything)
  if (config.textGlowWidth > 0) {
      ctx.save();
      // Scale glow width for resolution
      ctx.shadowBlur = config.textGlowWidth * 4 * scaleMultiplier; 
      ctx.shadowColor = config.textGlowColor;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
      ctx.fillStyle = config.textGlowColor; // Draw fill as glow color to intensify
      
      // Draw glow multiple times for intensity if needed, or just once
      drawLines((text, x, y) => ctx.fillText(text, x, y));
      ctx.restore();
  }

  // 7. Draw 3D Fake / Shifted Text Pass (Behind Main, possibly behind or mixed with shadow)
  if (config.text3DOffsetX !== 0 || config.text3DOffsetY !== 0) {
      ctx.save();
      ctx.fillStyle = config.text3DColor;
      // Adjust offsets for scale
      const offsetX = config.text3DOffsetX * (scaleFactor / 3); 
      const offsetY = config.text3DOffsetY * (scaleFactor / 3);
      
      drawLines((text, x, y) => {
          ctx.fillText(text, x + offsetX, y + offsetY);
      });
      ctx.restore();
  }

  // 8. Draw Drop Shadow Pass (Enhanced)
  if (config.textShadowOpacity > 0) {
      ctx.save();
      
      // Use specific shadow color if provided (with opacity), or fallback to black
      const shadowColorBase = config.textShadowColor || '#000000';
      
      ctx.shadowColor = shadowColorBase;
      // If we don't have a specific blur set, use the opacity-based calculation from before, otherwise use specific
      // Scale blur
      const blurAmount = config.textShadowBlur !== undefined ? config.textShadowBlur * 2 : 15 * config.textShadowOpacity;
      ctx.shadowBlur = blurAmount * scaleMultiplier;
      
      // Scale offsets
      ctx.shadowOffsetX = 4 * scaleMultiplier;
      ctx.shadowOffsetY = 4 * scaleMultiplier;
      
      // For shadow color to show clearly, we draw the text in the shadow color 
      // but applying globalAlpha to modulate intensity if needed
      ctx.globalAlpha = config.textShadowOpacity; 
      ctx.fillStyle = shadowColorBase;
      
      drawLines((text, x, y) => ctx.fillText(text, x, y));
      ctx.restore();
  }

  // 9. Draw Outline & Main Text
  ctx.save();
  
  // Super Stroke Logic (Behind Main Text)
  if (config.textSuperStrokeWidth && config.textSuperStrokeWidth > 0) {
      ctx.save();
      // Scale stroke width for canvas
      ctx.lineWidth = config.textSuperStrokeWidth * 1.5 * scaleMultiplier; 
      ctx.strokeStyle = config.textSuperStrokeColor;
      ctx.lineJoin = 'round';
      ctx.miterLimit = 2;
      
      drawLines((text, x, y) => {
          ctx.strokeText(text, x, y);
      });
      ctx.restore();
  }

  // Outline setup
  if (config.textOutlineWidth > 0) {
      // lineWidth is relative to fontSize, which is already scaled
      ctx.lineWidth = fontSize * (config.textOutlineWidth / 100) * 0.2; 
      ctx.strokeStyle = config.textOutlineColor;
      ctx.lineJoin = 'round';
  }
  
  // Text Gradient Logic
  if (config.textGradientColors && config.textGradientColors.length >= 2) {
      // Calculate bounding box of text for gradient
      // Simple approximation: from top line to bottom line
      const gradientStartY = startY - (pxLineHeight/2);
      const gradientEndY = startY + (lines.length * pxLineHeight) - (pxLineHeight/2);
      
      const textGradient = ctx.createLinearGradient(0, gradientStartY, 0, gradientEndY);
      config.textGradientColors.forEach((color, index) => {
          textGradient.addColorStop(index / (config.textGradientColors!.length - 1), color);
      });
      ctx.fillStyle = textGradient;
  } else {
      ctx.fillStyle = config.textColor;
  }
  
  drawLines((text, x, y) => {
      if (config.textOutlineWidth > 0) {
          ctx.strokeText(text, x, y);
      }
      ctx.fillText(text, x, y);
  });
  ctx.restore();

  // 10. Watermark (Free Version Only)
  if (!isPremium) {
      ctx.save();
      
      const wmText = "InstaQuote";
      const wmFontSize = width * 0.05; // 5% of width
      
      // Use a bold sans-serif font for readability
      ctx.font = `900 ${wmFontSize}px Inter, sans-serif`;
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      // Low opacity as requested
      ctx.globalAlpha = 0.2; 
      
      // Subtle shadow for visibility on light/dark backgrounds
      ctx.shadowColor = 'rgba(0,0,0,0.5)';
      ctx.shadowBlur = 4 * scaleMultiplier;
      ctx.shadowOffsetX = 1 * scaleMultiplier;
      ctx.shadowOffsetY = 1 * scaleMultiplier;
      
      // Position: Center-Bottom (10% from bottom)
      const x = width / 2;
      const y = height * 0.9;
      
      // Draw Quote Icon + Text
      ctx.fillText(`❝ ${wmText}`, x, y);
      
      ctx.restore();
  }

  // 11. Export
  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      resolve(blob);
    }, 'image/jpeg', 0.9);
  });
};